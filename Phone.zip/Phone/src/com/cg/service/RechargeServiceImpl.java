package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.RechargeRepository;
import com.cg.entities.Recharge;

@Service
@Transactional
public class RechargeServiceImpl implements RechargeService{
	@Autowired
	private RechargeRepository rechargeRepository;
	@Override
	public Recharge save(Recharge recharge) {
	
		return rechargeRepository.save(recharge);
	}

	@Override
	public List<Recharge> loadAll() {
	
		return rechargeRepository.loadAll();
	}

	@Override
	public Recharge search(int rechargeId) {
		
		return rechargeRepository.search(rechargeId);
	}

}
