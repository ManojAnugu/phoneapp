package com.cg.service;

import java.util.List;

import com.cg.entities.Recharge;



public interface RechargeService {
	public abstract Recharge save(Recharge recharge);
	public abstract List<Recharge> loadAll();
	public abstract Recharge search(int i);
}
