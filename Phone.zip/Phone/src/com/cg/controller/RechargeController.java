package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.cg.entities.Recharge;
import com.cg.service.RechargeService;

;


@Controller
public class RechargeController {
	@Autowired
	private RechargeService rechargeService;
	
	@RequestMapping("/recharge")
	public String getHomePage(Model model) {
		model.addAttribute("rcList", rechargeService.loadAll());
		model.addAttribute("plans",new String[] {"Rs:10 TT:7.35","Rs:30 TT:26.45","Rs:60 TT:51-100","Rs:100 FTT+250 MB data for 28 days","Rs:200 UL TT+UL data for 28 days"});
		model.addAttribute("recharge",new Recharge());
		
		return "recharge";
		
	}
	
	@RequestMapping("/rechargetransactions")
	public String getrechargetransactionsPage(Model model) {
		model.addAttribute("rcList", rechargeService.loadAll());
		model.addAttribute("recharge",new Recharge());
		
		return "rechargetransactions";
		
	}
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String sayHello(@ModelAttribute("recharge") Recharge recharge,Model model) {
		recharge=rechargeService.save(recharge);
		model.addAttribute("message","Recharge with id "+recharge.getRechargeId()+" done successfully!");
		
		return "redirect:/recharge.html";
		
	}
	
		@RequestMapping("/index")
			public String indexFunc(Model model)
			{	//model.addAttribute("Recharge",new Recharge());
				return "index";
			} 
		 

	
		@RequestMapping(value="/searchbyid",method=RequestMethod.POST)
		public String sayHellotome(Model model,@RequestParam("rechargeId") String rechargeId) {
			
		model.addAttribute("recharge",rechargeService.search(Integer.parseInt(rechargeId)));
			
			return "searchbyid";
			
		}
	
	
	
	
	
	


	/*@RequestMapping("/display")
	public String display(Model model,@RequestParam("en") String firstName,String lastName)
	{
	   model.addAttribute("firstName",firstName);
	   model.addAttribute("lastName",lastName);
		return "display";
		
	}  
	
	@RequestMapping("/searchbyid")
	public String display1(Model model,@RequestParam("en") long rechargeId)
	{
	   model.addAttribute("rechargeId",rechargeId);
	   model.addAttribute("recharge",new Recharge());
	   
		return "searchbyid";
		
	}  */
}
